import MoneyManager from './components/MoneyManager'

import './App.css'

const App = () => <MoneyManager />

export default App
